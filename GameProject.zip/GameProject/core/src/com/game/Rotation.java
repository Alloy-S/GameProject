package com.game;

import com.badlogic.gdx.math.Vector2;

public class Rotation {
    Vector2 position;


}
