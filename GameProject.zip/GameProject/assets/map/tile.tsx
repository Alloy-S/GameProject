<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="tile" tilewidth="16" tileheight="16" tilecount="720" columns="40">
 <image source="tile_1.png" width="641" height="288"/>
</tileset>
