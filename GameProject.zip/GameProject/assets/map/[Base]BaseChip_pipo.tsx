<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="[Base]BaseChip_pipo" tilewidth="16" tileheight="16" tilecount="1992" columns="8">
 <image source="Compressed/Pipoya RPG Tileset 16x16/Pipoya RPG Tileset 16x16/[Base]BaseChip_pipo.png" width="128" height="3984"/>
 <tile id="0">
  <properties>
   <property name="bushes" value=""/>
  </properties>
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0616927" y="2.5294" width="16" height="16" visible="0"/>
  </objectgroup>
 </tile>
 <tile id="41" type="bush"/>
</tileset>
